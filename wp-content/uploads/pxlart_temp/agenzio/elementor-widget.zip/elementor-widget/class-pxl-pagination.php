<?php

class PxlPagination_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'pxl_pagination';
    protected $title = 'Case Pagination';
    protected $icon = 'eicon-apps';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[{"name":"section_content","label":"Content","tab":"content","controls":[]}]}';
    protected $styles = array(  );
    protected $scripts = array(  );
}